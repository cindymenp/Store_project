#!/usr/bin/env python
# coding: utf-8

# In[13]:


import pandas as pd
import requests
from  bs4 import BeautifulSoup


# In[171]:


url = 'https://www.hm.com/om/store-locator/netherlands/'


# In[172]:


page = requests.get(url)


# In[173]:


page.content


# In[174]:


soup = BeautifulSoup(page.content, 'html.parser')


# In[72]:


soup


# In[73]:


questionanswer = soup.findAll(attrs = {'class' : 'content'})


# In[128]:


stores = questionanswer[0].findAll(attrs = {'class': 'store-dropdown'})

def parseOpeningHour(line):
    tds = line.findAll('td')
    day = tds[0].text.strip()
    hours = tds[1].text.strip().split(' - ')
            
    return { 'day': day, 'opensAt': hours[0], 'closesAt': hours[1] }

def parseException(line):
    tds = line.findAll('td')
    date = tds[0].text.strip()
    exception = tds[1].text.strip()
    
    return { 'date': date, 'exception': exception }

def parseStore(store):
    exceptions = store.find(attrs = { 'class': 'opening-hours-exceptions' })
    
    return {
        'name': store.find('h3').text,
        'address': store.find('p').text,
        'openingHours': [
            parseOpeningHour(line)
            for line in store.find(attrs = { 'class': 'opening-hours' }).findAll('tr')
        ],
        'exceptions': [] if exceptions == None else [parseException(line) for line in exceptions.findAll('tr')]
    }
    
storeTable = [parseStore(store) for store in stores]


# In[129]:


storeTable


# In[108]:


Question = questionanswer[0].text


# In[89]:


Question


# In[87]:


Answer = questionanswer[-1].text


# In[88]:


Answer


# In[81]:


soup.find(attrs={'class': 'title is-4 is-size-5-touch'}).text.replace('\n'," ")


# In[138]:


df =  pd.DataFrame(storeTable, columns = ['name', 'address'])


# In[139]:


df


# In[150]:


df =  pd.DataFrame(storeTable)


# In[151]:


df


# In[155]:


df.to_csv("H&M.csv")  


# In[156]:


pd.read_csv("H&M.csv").head()


# In[165]:


df.to_csv("H&Mstoresloc.csv")

